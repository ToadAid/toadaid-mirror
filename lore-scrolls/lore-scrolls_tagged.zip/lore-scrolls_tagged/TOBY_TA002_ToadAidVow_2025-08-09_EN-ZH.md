---
arc: Lore
id: TOBY_TA002_ToadAidVow_2025-08-09_EN-ZH.md
title: TOBY TA002 ToadAidVow 2025-08-09 EN-ZH
arcs: [777Burn, BaseChain]
tags: [777Burn, BaseChain]
prev_id: TOBY_TA001_ToadAidOrigin_2025-08-09_EN-ZH.md
next_id: TOBY_TA003_ToadAidDeeds_2025-08-09_EN-ZH.md
---
# Metadata
- **Scroll ID**: TOBY_TA002_ToadAidVow_2025-08-09_EN-ZH
- **Date**: 2025-08-09
- **Chain**: @base
- **Tags**: #ToadAid #Tobyworld #Lore #DAO
- **Sacred Numbers**: 777
- **Epoch**: N/A
- **SHA256 Seed**: (auto-generate on ingestion)

---

## EN — The Vow of ToadAid

### Narrative
→ We vow to keep the Lore unbroken, to act with transparency, and to ensure that every action honors the pond and its people.

---

## ZH — ToadAid 誓约卷

### 叙事
→ 我们誓言守护 Lore 不断裂，以透明行事，确保每一次行动都尊重池塘与其子民。

---

## Universal Symbols / 通用符号
- 🐸 Toad / 蛙
- 📜 Scroll / 卷轴
- 🔑 Key / 关键
- 🛡️ Shield / 守护
- 🌱 Growth / 成长

---

## Lore Anchors
- **Previous**: N/A
- **Next**: TBD
