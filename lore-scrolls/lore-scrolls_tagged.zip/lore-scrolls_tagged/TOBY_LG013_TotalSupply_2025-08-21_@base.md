---
arc: Toby
id: TOBY_LG013_TotalSupply_2025-08-21_@base.md
series: L
date: 2025-08-21
number: G013
title: TotalSupply
arcs: [BaseChain]
tags: [BaseChain, 'Month:2025-08', 'Series:L', 'Year:2025']
prev_id: TOBY_LG012_ToadgodFinalPost_2025-08-21_@base.md
next_id: TOBY_LG014_CanIBuyTaboshi1Today_2025-08-21_@base.md
prev_L_id: TOBY_LG012_ToadgodFinalPost_2025-08-21_@base.md
next_L_id: TOBY_LG014_CanIBuyTaboshi1Today_2025-08-21_@base.md
chain: @base
---
# LG-013 — What is the total supply of $TOBY?

## EN — Canon Answer
- **Total supply:** **420,000,000,000,000 ($420T)**.
- Note: Earlier figures like **290T** were **partial distributions**, **not** the total supply.

