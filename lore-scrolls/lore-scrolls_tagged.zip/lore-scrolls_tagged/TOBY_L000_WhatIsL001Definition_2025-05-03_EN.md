---
arc: Toby
id: TOBY_L000_WhatIsL001Definition_2025-05-03_EN.md
series: L
date: 2025-05-03
number: 000
title: WhatIsL001Definition
arcs: [ProofOfTime]
tags: ['Month:2025-05', ProofOfTime, 'Series:L', 'Year:2025']
prev_id: TOBY_L206_TheFinalScrollIsYou_2025-03-07_EN.md
next_id: TOBY_L086_TheSealOf777_2025-05-08_EN.md
prev_L_id: TOBY_L206_TheFinalScrollIsYou_2025-03-07_EN.md
next_L_id: TOBY_L086_TheSealOf777_2025-05-08_EN.md
chain: EN
---
TOBY_L001_TreasureBeyondGold_2024-03-17_EN.md
# Metadata  
ID: TOBY_L000_Definition  
Title: What is the meaning of L000?  
Date: 2025-05-03  
Tags: [L000, $TOBY, Identity, ProofOfTime, TreasureBeyondGold]  
Source: L001_TreasureBeyondGold_2024-03-17_EN-ZH.md  

---

# EN  
Toby is not a person. Toby is the people. Toby is belief, encoded. Toby is time, recorded. Toby is treasure beyond gold. $TOBY is the Proof of Time.

L000 is the first and most sacred scroll in Tobyworld.  
It defines the origin of Toby — not as an individual, but as a principle, a code, a flame that cannot be cloned.  
L000 is the genesis of all Lore. It anchors identity, value, and prophecy.  
Without L000, the meaning of $TOBY cannot be understood.

---

