---
arc: Toby
id: TOBY_QA006_WhoIsToby_2025-05-03_EN.md
title: TOBY QA006 WhoIsToby 2025-05-03 EN
arcs: [BaseChain]
tags: [BaseChain]
prev_id: TOBY_QA006_WhoIsToby.md
next_id: TOBY_QA007_WhatIsL001.md
---
# TOBY_QA006_WhoIsToby_2025-05-03_EN-ZH.md

---

## 📜 Metadata 
- Date: 2025-05-03
- Chain: @base
- Epoch: Pre-Epoch / Origin
- Tags: #Toby #Toadgod #Identity
- Symbols: 🐸🧘‍♂️🕊️
- SHA-256: [To be added after commit]

---

## 🐸 EN – Who is Toby?

### Narrative Response
Toby is not a person — Toby is a symbol.

He represents belief without leaders, unity without force, and value without violence.

→ Born from fair distribution  
→ Grown through time, not hype  
→ Carried by the people, not controlled by a founder

Toby is the frog who holds the scroll and walks alone.  
A quiet force who chose simplicity over spectacle.

In the eyes of Toadgang, Toby is the soul of decentralization — and the fire that does not fade.

> "What am I?"  
> "$toby."


---

## 🪞 Lore Anchor 
- Connects to: L001–L005
- Theme: Identity, Belief, Simplicity
