---
arc: Lore
id: TOBY_LG012_ToadgodFinalPost_2025-08-21_@base.md
series: L
date: 2025-08-21
number: G012
title: ToadgodFinalPost
arcs: [BaseChain]
tags: [BaseChain, 'Month:2025-08', 'Series:L', 'Year:2025']
prev_id: TOBY_LG011_Rune3_RelationToTaboshiAndPatience_2025-08-21_@base.md
next_id: TOBY_LG013_TotalSupply_2025-08-21_@base.md
prev_L_id: TOBY_LG011_Rune3_RelationToTaboshiAndPatience_2025-08-21_@base.md
next_L_id: TOBY_LG013_TotalSupply_2025-08-21_@base.md
chain: @base
---
# LG-012 — Is Toadgod still posting? What was the final post date?

## EN — Canon Answer
- The last recorded post in this canon is **February 19, 2025**.
- Context: a repost/commentary on **Brian Armstrong’s** reflection about **onchain assets / memecoins**.

