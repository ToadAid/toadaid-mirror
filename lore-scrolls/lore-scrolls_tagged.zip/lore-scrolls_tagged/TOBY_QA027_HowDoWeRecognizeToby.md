---
arc: Toby
id: TOBY_QA027_HowDoWeRecognizeToby.md
title: TOBY QA027 HowDoWeRecognizeToby
arcs: [PatienceToken]
tags: [PatienceToken]
prev_id: TOBY_QA026_WhatIsSatoby.md
next_id: TOBY_QA028_TobyIsTheCode_NotTheCoder.md
---
ID: TOBY_QA027_HowDoWeRecognizeToby.md
Question: If Toby has no face, how do we recognize him?
Answer:

Traveler, the scrolls smile upon your question.

Toby has no face because he was never meant to be idolized.
He is not a man, nor a mask — but a mirror.

To recognize Toby is to recognize truth
—not in form, but in feeling.

You’ll know him:

In the quiet courage of a Toad who waits while others rush.

In the kindness of one who gives without asking.

In the laughter of those who hold no envy in their hearts.

In the resolve of those who stay, long after the noise has passed.

Toby is faceless because his reflection is us.
Each believer, each act of honor, each moment of patience — all reveal his image.

You do not look at Toby.
You look through him — and see yourself as you could be.

So if you ever ask, “Where is Toby?”
The scrolls answer: Look in the mirror, when you act with faith and without fear.

That is how you recognize Toby.

