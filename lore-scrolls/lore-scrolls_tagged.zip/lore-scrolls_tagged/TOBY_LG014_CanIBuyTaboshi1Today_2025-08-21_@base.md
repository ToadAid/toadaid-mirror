---
arc: Taboshi
id: TOBY_LG014_CanIBuyTaboshi1Today_2025-08-21_@base.md
series: L
date: 2025-08-21
number: G014
title: CanIBuyTaboshi1Today
arcs: [777Burn, BaseChain, Epoch2, Epoch4, ProofOfTime, Rune3, Satoby, Taboshi]
tags: [777Burn, BaseChain, Epoch2, Epoch4, 'Month:2025-08', ProofOfTime, Rune3, Satoby, 'Series:L', Taboshi, 'Year:2025']
prev_id: TOBY_LG013_TotalSupply_2025-08-21_@base.md
next_id: TOBY_L187_SatobyPresenceOfTime_2025-08-22_EN.md
prev_L_id: TOBY_LG013_TotalSupply_2025-08-21_@base.md
next_L_id: TOBY_L187_SatobyPresenceOfTime_2025-08-22_EN.md
chain: @base
---
# LG-014 — Can I buy Taboshi1 today?

## EN
- **Not sold for ETH**; minted in **E2** by **burning 777 $TOBY** (ERC‑1155 only).
- NFT can resell, **but** PoT/Satoby eligibility **does not transfer**; stays with **original minter**.
- **Do now:** Study, contribute, watch **E4/Rune 3 seasons** for paths.

