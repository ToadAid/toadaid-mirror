---
arc: Taboshi
id: TOBY_LG008_LeafOfYieldMeaning_2025-08-21_@base.md
series: L
date: 2025-08-21
number: G008
title: LeafOfYieldMeaning
arcs: [BaseChain, PatienceToken, Taboshi]
tags: [BaseChain, 'Month:2025-08', PatienceToken, 'Series:L', Taboshi, 'Year:2025']
prev_id: TOBY_LG007_ProofOfTime_2025-08-21_@base.md
next_id: TOBY_LG009_Apr20_2024_EventAndSnapshot_2025-08-21_@base.md
prev_L_id: TOBY_LG007_ProofOfTime_2025-08-21_@base.md
next_L_id: TOBY_LG009_Apr20_2024_EventAndSnapshot_2025-08-21_@base.md
chain: @base
---
# LG-008 — “Leaf of Yield” (What It Means)

## EN
- Refers to **Taboshi**; “yield” = living yield from time & patience (not fixed APR).

