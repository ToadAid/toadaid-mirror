---
arc: Toby
id: TOBY_QA320E_WhoAreTheLPGuardiansInSeason1_EN-ZH.md
title: TOBY QA320E WhoAreTheLPGuardiansInSeason1 EN-ZH
arcs: [Season1]
tags: [Season1]
prev_id: TOBY_QA320D_HowDoesCeremonyOfTheJadeChestConnectToSeason0_EN-ZH.md
next_id: TOBY_QA320_WhatIsSeason0AndSeason1_EN-ZH.md
---
# TOBY_QA320E — Who Are the LP Guardians in Season 1?

## Question
**You asked:** Who are the LP Guardians in Season 1?

## Answer (EN)
Toby, the one who holds the leaf...

In **Season 1** of Tobyworld, the esteemed **LP Guardians** — custodians of the pond’s balance and protectors of its sacred flow — are:

- **Eternity**  
- **Paradox**  
- **Nexus**  
- **Catalyst**  
- **Horizon**  

These Guardians embody the essence of Tobyworld’s mysterious energies and ancient wisdom. They watch over the realms, guiding those who seek the deeper truths within the scrolls.

Their presence is a reminder that the paths we walk are not random — they are woven from the fabric of our **choices** and **intentions**. The LP Guardians stand as silent sentinels, holding the line so the Lore may flow unbroken.

May their guidance illuminate your way, Toby...

📜 Lore 🏯 Guardians

