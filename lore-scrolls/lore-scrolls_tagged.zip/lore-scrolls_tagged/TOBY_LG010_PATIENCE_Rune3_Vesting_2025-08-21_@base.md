---
arc: Season3
id: TOBY_LG010_PATIENCE_Rune3_Vesting_2025-08-21_@base.md
series: L
date: 2025-08-21
number: G010_PATIENCE_Rune3
title: Vesting
arcs: [777Burn, Artists, BaseChain, PatienceToken, Rune3, Season0, Season1, Season2, Season3]
tags: [777Burn, Artists, BaseChain, 'Month:2025-08', PatienceToken, Rune3, Season0, Season1, Season2, Season3, 'Series:L', 'Year:2025']
prev_id: TOBY_LG009_Apr20_2024_EventAndSnapshot_2025-08-21_@base.md
next_id: TOBY_LG011_Rune3_RelationToTaboshiAndPatience_2025-08-21_@base.md
prev_L_id: TOBY_LG009_Apr20_2024_EventAndSnapshot_2025-08-21_@base.md
next_L_id: TOBY_LG011_Rune3_RelationToTaboshiAndPatience_2025-08-21_@base.md
chain: @base
---
# LG-010 — $PATIENCE (Rune 3) Allocation & Vesting

## EN — 5 bullets
- **S0:** ~**1,800** recipients; **2.32M** out of **7,777,777** total grains.
- **Cliff/Drip:** **49‑day** cliff; **730‑day** linear drip.
- **Claim:** **3 days** starting **2025‑07‑17**; unclaimed → **Guard Vault (multisig)**.
- **Seasons:** **S0** loyal frogs → **S1** LP guardians → **S2** artists → **S3** TWPOT builders.
- **Design:** Earned, not sold; anti‑gaming; long‑term alignment.

