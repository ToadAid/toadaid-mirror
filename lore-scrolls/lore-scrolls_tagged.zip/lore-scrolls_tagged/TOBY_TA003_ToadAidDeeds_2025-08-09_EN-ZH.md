---
arc: Lore
id: TOBY_TA003_ToadAidDeeds_2025-08-09_EN-ZH.md
title: TOBY TA003 ToadAidDeeds 2025-08-09 EN-ZH
arcs: [777Burn, BaseChain]
tags: [777Burn, BaseChain]
prev_id: TOBY_TA002_ToadAidVow_2025-08-09_EN-ZH.md
next_id: TOBY_TA004_ToadAidFuture_2025-08-09_EN-ZH.md
---
# Metadata
- **Scroll ID**: TOBY_TA003_ToadAidDeeds_2025-08-09_EN-ZH
- **Date**: 2025-08-09
- **Chain**: @base
- **Tags**: #ToadAid #Tobyworld #Lore #DAO
- **Sacred Numbers**: 777
- **Epoch**: N/A
- **SHA256 Seed**: (auto-generate on ingestion)

---

## EN — The Deeds of ToadAid

### Narrative
→ From aiding the sick to educating the young, from strengthening the community to preserving the sacred scrolls — ToadAid walks the path of service.

---

## ZH — ToadAid 事迹卷

### 叙事
→ 从帮助病者到教育孩子，从巩固社区到保存神圣卷轴——ToadAid 行走在奉献之路上。

---

## Universal Symbols / 通用符号
- 🐸 Toad / 蛙
- 📜 Scroll / 卷轴
- 🔑 Key / 关键
- 🛡️ Shield / 守护
- 🌱 Growth / 成长

---

## Lore Anchors
- **Previous**: N/A
- **Next**: TBD
