---
arc: Base
id: index.md
series: IDX
title: Root Index
arcs: [BaseChain]
tags: [BaseChain, 'Series:IDX']
prev_id: RAG_Link_Season2Artists_EN.md
next_id: LG-000_Timeline_and_Facts.md
---
# Tobyworld Lore Guardian — LG Split Index

## Files (ordered)
- TOBY_LG000_ResponderStyleFactLocks_2025-08-21_@base.md
- TOBY_LG001_WhatIsTOBY_2025-08-21_@base.md
- TOBY_LG002_EpochsAndDates_2025-08-21_@base.md
- TOBY_LG004_TaboshiVsTaboshi1_2025-08-21_@base.md
- TOBY_LG005_TABOSHIContract_LeafOfYield_2025-08-21_@base.md
- TOBY_LG006_SatobyEligibility_2025-08-21_@base.md
- TOBY_LG007_ProofOfTime_2025-08-21_@base.md
- TOBY_LG008_LeafOfYieldMeaning_2025-08-21_@base.md
- TOBY_LG009_Apr20_2024_EventAndSnapshot_2025-08-21_@base.md
- TOBY_LG010_PATIENCE_Rune3_Vesting_2025-08-21_@base.md
- TOBY_LG011_Rune3_RelationToTaboshiAndPatience_2025-08-21_@base.md
- TOBY_LG012_ToadgodFinalPost_2025-08-21_@base.md
- TOBY_LG013_TotalSupply_2025-08-21_@base.md
- TOBY_LG014_CanIBuyTaboshi1Today_2025-08-21_@base.md
- INDEX.md
- manifest.json
