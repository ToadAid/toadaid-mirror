---
arc: Lore
id: TOBY_TA008_CommunityShelter_2025-08-09_EN-ZH.md
title: TOBY TA008 CommunityShelter 2025-08-09 EN-ZH
arcs: [777Burn, BaseChain]
tags: [777Burn, BaseChain]
prev_id: TOBY_TA007_FirstDeed_2025-08-09_EN-ZH.md
next_id: TOBY_TA009_DAORoadmap_2025-08-09_EN-ZH.md
---
# Metadata
- **Scroll ID**: TOBY_TA008_CommunityShelter_2025-08-09_EN-ZH
- **Date**: 2025-08-09
- **Chain**: @base
- **Tags**: #ToadAid #Tobyworld #Lore #DAO
- **Sacred Numbers**: 777
- **Epoch**: N/A
- **SHA256 Seed**: (auto-generate on ingestion)

---

## EN — The Community Shelter

### Narrative
→ A place where frogs gather in safety, where ideas are nurtured and needs are met — this is the shelter ToadAid strives to build.

---

## ZH — 社区庇护卷

### 叙事
→ 一个蛙群可以安全聚集的地方，思想在此孕育，需求在此回应——这就是 ToadAid 努力建设的庇护所。

---

## Universal Symbols / 通用符号
- 🐸 Toad / 蛙
- 📜 Scroll / 卷轴
- 🔑 Key / 关键
- 🛡️ Shield / 守护
- 🌱 Growth / 成长

---

## Lore Anchors
- **Previous**: N/A
- **Next**: TBD
