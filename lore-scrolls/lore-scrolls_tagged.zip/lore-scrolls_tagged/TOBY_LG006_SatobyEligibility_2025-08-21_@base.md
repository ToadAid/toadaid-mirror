---
arc: Taboshi
id: TOBY_LG006_SatobyEligibility_2025-08-21_@base.md
series: L
date: 2025-08-21
number: G006
title: SatobyEligibility
arcs: [777Burn, BaseChain, Epoch2, ProofOfTime, Satoby, Taboshi]
tags: [777Burn, BaseChain, Epoch2, 'Month:2025-08', ProofOfTime, Satoby, 'Series:L', Taboshi, 'Year:2025']
prev_id: TOBY_LG005_TABOSHIContract_LeafOfYield_2025-08-21_@base.md
next_id: TOBY_LG007_ProofOfTime_2025-08-21_@base.md
prev_L_id: TOBY_LG005_TABOSHIContract_LeafOfYield_2025-08-21_@base.md
next_L_id: TOBY_LG007_ProofOfTime_2025-08-21_@base.md
chain: @base
---
# LG-006 — What is Satoby & Who Is Eligible?

## EN — Canon Summary
- **Satoby** = outcome of **Proof of Time (PoT)**, rewarding early, steady participation.
- **Eligibility bound to original Taboshi1 minter** (E2, 777 $TOBY burn on Zora); **non‑transferable**.

