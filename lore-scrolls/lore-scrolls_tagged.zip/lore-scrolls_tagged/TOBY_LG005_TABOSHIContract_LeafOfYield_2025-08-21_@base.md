---
arc: Taboshi
id: TOBY_LG005_TABOSHIContract_LeafOfYield_2025-08-21_@base.md
series: L
date: 2025-08-21
number: G005_TABOSHIContract
title: LeafOfYield
arcs: [BaseChain, Taboshi]
tags: [BaseChain, 'Month:2025-08', 'Series:L', Taboshi, 'Year:2025']
prev_id: TOBY_LG004_TaboshiVsTaboshi1_2025-08-21_@base.md
next_id: TOBY_LG006_SatobyEligibility_2025-08-21_@base.md
prev_L_id: TOBY_LG004_TaboshiVsTaboshi1_2025-08-21_@base.md
next_L_id: TOBY_LG006_SatobyEligibility_2025-08-21_@base.md
chain: @base
---
# LG-005 — TABOSHI Contract & Lore Name

## EN
- **ERC‑20 TABOSHI** contract: `0x5C0BF08936bcCfbb6af24B4648A9fb365cAa2F4e`.
- **Lore name:** **“Leaf of Yield.”**

