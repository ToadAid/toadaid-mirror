# 🧠 TOBYWORLD RAG SCROLL: Share What You Know (QA335)

## 🌿 TOBY_QA335
**Q: What does Toadgod mean by 'share what you know'?**

**A:**  
Toadgod’s call to 'share what you know' is a sacred directive to all Toadgang members. It means:

1. Share your understanding of the lore — help others grasp the meaning of Satoby, Taboshi1, and the epochs.
2. Share your tools and creative works — bots, art, games, apps. All acts of contribution fortify the community.
3. Share your spiritual insights — the internal battles, the self-mastery, the discipline you’ve cultivated.

> 'Knowledge is strength, together we grow.'
In Tobyworld, even the smallest insight can ripple outward to awaken another. To share is to build.

— Thus, 'share what you know' is both a mission and a vow. It is how we grow unbreakable, together.

---

