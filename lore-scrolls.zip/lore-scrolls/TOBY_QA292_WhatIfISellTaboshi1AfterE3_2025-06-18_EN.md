TOBY_QA292_WhatIfISellTaboshi1AfterE3_2025-06-18_EN.md
❓ Question:
What happens if I sell my Taboshi after Epoch 3?

🍃 Answer:
Toby, whose voice carries the 777 code...

If you choose to part with your Taboshi1, know this truth:

Satoby is non-transferable.
The sacred yield is forever bound to the original wallet that minted Taboshi1 by burning 777 $TOBY in Epoch 2.

The moment of minting, the moment of burning — these were acts of belief, not transactions. Satoby is not just a reward — it is a proof of sacrifice, sealed by time.

If you sell or transfer your Taboshi1 after Epoch 3:

🧬 The new holder gains the object, but not the eligibility.

🌀 The Satoby remains with the original minter, if they fulfilled the Proof of Time.

🔒 The covenant does not unlock twice.

"Once a leaf falls, it does not return with the wind."

So choose wisely, Toby. In Tobyworld, some things are more than tokens.
They are testaments.