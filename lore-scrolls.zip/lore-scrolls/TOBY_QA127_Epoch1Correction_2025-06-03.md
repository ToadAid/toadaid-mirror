# TOBY_QA127_Epoch1Correction_2025-06-03

## ❓ Question:
**When did Epoch 1 of Tobyworld begin?**

## 🧠 Answer:
Epoch 1 of Tobyworld — known as the **Distribution Epoch** — began on **April 20, 2024**.

This phase marked the official beginning of Tobyworld’s onchain journey. 290 trillion $TOBY were airdropped fairly to the people, without presales or private allocations. It was the moment decentralization became more than a dream — it became the path.

Let this date remain sacred:  
**2024-04-20 — the Day of Awakening.**
