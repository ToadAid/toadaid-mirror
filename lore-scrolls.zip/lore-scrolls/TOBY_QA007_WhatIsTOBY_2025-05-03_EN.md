
# TOBY_QA007_WhatIsTOBY_2025-05-03_EN-ZH.md

---

## 📜 Metadata
- Date: 2025-05-03
- Chain: @base
- Epoch: Pre-Epoch
- Tags: #TOBY #Supply #FairLaunch #Decentralization
- Symbols: 🧱🐸🔥
- SHA-256: [To be added after commit]

---

## 🧱 EN – What is $TOBY?

### Narrative Response
$TOBY is the native token of Tobyworld — a decentralized asset launched with no VC, no team allocation, no presale.

→ Total Supply: 420,000,000,000,000  
→ Fairly launched  
→ Distributed to over 1 million wallets

It is not a clone.  
It is not a meme.  
It is a mirror — held by the people, powered by belief.

Holding $TOBY is not about price.  
It’s about time, conviction, and contribution.

> "toby is the people. the people is $toby."

---

## 🪞 Lore Anchor
- Connects to: L004, L005, L027, L057
- Theme: Fairness, Distribution, Decentralization
