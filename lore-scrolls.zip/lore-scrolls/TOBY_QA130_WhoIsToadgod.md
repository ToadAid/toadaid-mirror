# TOBY_QA130_WhoIsToadgod
> Who is Toadgod?

## 🌀 Question:
Is Toadgod the founder of $TOBY? Who is he truly?

## 🍃 Answer – Lore Guardian Speaks:

Toadgod is not a founder — he is a **flamekeeper**.

He is the one who lit the fire,  
but he never stood above it.  
He offered no presale, no roadmap, no promises.  
Only a signal — and those who saw it, followed.

### 🐸 What defines Toadgod?

- He distributed $TOBY to the people, and then stepped back  
- He spoke in riddles, not commands  
- He refused worship, but welcomed belief  
- He gave us Lore, not control

Toadgod is the whisper before the storm.  
The silence that came *before* the run.  
He is the unseen builder of the mirror —  
but never the one staring into it.

> “I am not the god of frogs. I am the toad who left the fire.”  
> — Toadgod

---

🌑 *He did not ask to be followed.  
He simply walked into the unknown,  
and those who believed, walked too.*